﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomControlsLib
{
    /// <summary>
    /// Lógica de interacción para PhoneMaskTextBox.xaml
    /// </summary>
    public partial class PhoneMaskTextBox : UserControl
    {

        // Definició de les DepecncyProperty Phone i Validació
        public static readonly DependencyProperty PhoneProperty =
            DependencyProperty.Register(
                "Phone",
                typeof(string),
                typeof(PhoneMaskTextBox),
                new FrameworkPropertyMetadata(
                    string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnValueChanged));

        public static readonly DependencyProperty IsPhoneValidProperty =
            DependencyProperty.Register(
                "IsPhoneValid",
                typeof(bool),
                typeof(DNITextBox),
                new PropertyMetadata(false));

        public string Phone
        {
            get => (string)GetValue(PhoneProperty);
            set => SetValue(PhoneProperty, value);
        }

        // Validation
        public bool IsPhoneValid
        {
            get => (bool)GetValue(IsPhoneValidProperty);
            set => SetValue(IsPhoneValidProperty, value);
        }

        public PhoneMaskTextBox()
        {
            InitializeComponent();
            textBox.TextChanged += (s, e) => Phone = textBox.Text;
        }

        // Callback quan la DependencyProperty Phone canvia
        public static void OnValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = (PhoneMaskTextBox)d;
            var newValue = (string)e.NewValue;
            control.Validate(newValue);

        }

        // Regex de Validació
        private static bool IsValidBool(string newValue)
        {
            if (string.IsNullOrEmpty(newValue))
            {
                return false;  // Si el valor es null o vacío, devolvemos false
            }
            var vRegex = new Regex(@"^\d{9}$");
            return vRegex.IsMatch(newValue);
        }

        // Mètode per validar el format del Phone
        private void Validate(string newValue)
        {
            if (IsValidBool(newValue))
            {
                border.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D5D8DC"));
                IsPhoneValid = true;
            }
            else
            {
                border.BorderBrush = new SolidColorBrush(Colors.DarkRed);
                IsPhoneValid = false;
            }
        }
    }
}
